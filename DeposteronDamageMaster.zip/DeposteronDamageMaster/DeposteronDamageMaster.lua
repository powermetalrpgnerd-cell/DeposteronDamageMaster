local _, class = UnitClass("player")
if class ~= "WARRIOR" then return end

SLASH_DEPOSTERONDAMAGEMASTER1 = "/ineeddeposteron"
SlashCmdList["DEPOSTERONDAMAGEMASTER"] = function()
  DeposteronDamageMaster()
end

-- Procura o botão Attack nas action bars.
-- Em clientes Vanilla/Turtle WoW, o ícone padrão de Attack normalmente
-- utiliza a textura Ability_MeleeDamage.
local function FindAttackSlot()
  for slot = 1, 120 do
    local texture = GetActionTexture(slot)

    if texture then
      local lowerTexture = string.lower(texture)

      if string.find(lowerTexture, "ability_meleedamage") then
        return slot
      end
    end

    -- Fallback para clientes onde IsAttackAction funciona corretamente.
    if IsAttackAction and IsAttackAction(slot) then
      return slot
    end
  end

  return nil
end

-- Inicia Auto Attack somente quando ele ainda NÃO estiver ativo.
-- Isso evita que pressionar /ineeddeposteron novamente desligue o ataque.
local function StartAutoAttack()
  local attackSlot = FindAttackSlot()

  if attackSlot then
    if not IsCurrentAction(attackSlot) then
      UseAction(attackSlot)
    end
  end
end

function DeposteronDamageMaster()
  if not UnitExists("target")
    or UnitIsDead("target")
    or not UnitCanAttack("player", "target") then
    return
  end

  -- Prioridade 0: Auto Attack
  StartAutoAttack()

  -- Prioridade 1: Battle Shout (se não estiver ativo)
  local i = 1
  local hasBattleShout = false

  while true do
    local buffTexture = UnitBuff("player", i)

    if not buffTexture then
      break
    end

    if string.find(buffTexture, "Ability_Warrior_BattleShout") then
      hasBattleShout = true
      break
    end

    i = i + 1
  end

  if not hasBattleShout then
    CastSpellByName("Battle Shout")
    return
  end

  -- Prioridade 2: Execute (alvo com 20% ou menos de vida)
  local maxHealth = UnitHealthMax("target")

  if maxHealth and maxHealth > 0 then
    local healthPct = UnitHealth("target") / maxHealth

    if healthPct <= 0.20 then
      CastSpellByName("Execute")
      return
    end
  end

  -- Prioridade 3: Bloodthirst
  CastSpellByName("Bloodthirst")

  -- Prioridade 4: Whirlwind
  CastSpellByName("Whirlwind")

  -- Prioridade 5: Heroic Strike com 50+ Rage
  local rage = UnitMana("player")

  if rage and rage >= 50 then
    CastSpellByName("Heroic Strike")
  end
end
