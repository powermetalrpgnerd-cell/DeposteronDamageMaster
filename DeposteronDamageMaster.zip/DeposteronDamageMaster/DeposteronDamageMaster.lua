local _, class = UnitClass("player")
if class ~= "WARRIOR" then return end

SLASH_DEPOSTERONDAMAGEMASTER1 = "/ineeddeposteron"
SlashCmdList["DEPOSTERONDAMAGEMASTER"] = function()
  DeposteronDamageMaster()
end

-- Inicia o Auto Attack sem desligá-lo quando o botão for pressionado novamente.
-- Procura a habilidade Attack nas action bars (slots 1-72).
local function StartAutoAttack()
  local attackSlot = nil

  for i = 1, 72 do
    if IsAttackAction(i) then
      attackSlot = i
      break
    end
  end

  if attackSlot and not IsCurrentAction(attackSlot) then
    UseAction(attackSlot)
  end
end

function DeposteronDamageMaster()
  if not UnitExists("target")
    or UnitIsDead("target")
    or not UnitCanAttack("player", "target") then
    return
  end

  -- Prioridade 0: iniciar Auto Attack sem cancelar caso já esteja ativo
  StartAutoAttack()

  -- Prioridade 1: Battle Shout (se não estiver ativo)
  local i = 1
  local hasBattleShout = false

  while true do
    local buffTexture = UnitBuff("player", i)

    if not buffTexture then
      break
    end

    if string.find(buffTexture, "Ability_Warrior_BattleShout") then
      hasBattleShout = true
      break
    end

    i = i + 1
  end

  if not hasBattleShout then
    CastSpellByName("Battle Shout")
    return
  end

  -- Prioridade 2: Execute (alvo com 20% ou menos de vida)
  local maxHealth = UnitHealthMax("target")

  if maxHealth and maxHealth > 0 then
    local healthPct = UnitHealth("target") / maxHealth

    if healthPct <= 0.20 then
      CastSpellByName("Execute")
      return
    end
  end

  -- Prioridade 3: Bloodthirst
  CastSpellByName("Bloodthirst")

  -- Sem return:
  -- se Bloodthirst estiver em cooldown ou sem rage,
  -- o addon também tenta as próximas habilidades.

  -- Prioridade 4: Whirlwind
  CastSpellByName("Whirlwind")

  -- Prioridade 5: Heroic Strike (se com rage alta)
  local rage = UnitMana("player")

  if rage and rage >= 50 then
    CastSpellByName("Heroic Strike")
  end
end
